<?php
/*
 * OpenCart Bulgarian translation
 * Author: Veselin Totev (veselin.totev@gmail.com)
 * License: Free to use
 * Donate:
 *      PayPal: veskoto@gmail.com
 *      Bitcoin: 1QG2f8mGtbYiHc6k8ZzV4WhfcmVHs79QiK
 */
// Text
$_['text_subject']	= '%s - Мнение за продукт';
$_['text_waiting']	= 'Имате чакащи мнения за продукт.';
$_['text_product']	= 'Продукт: %s';
$_['text_reviewer']	= 'Потребител: %s';
$_['text_rating']	= 'Рейтинг: %s';
$_['text_review']	= 'Текст на мнение(отзив):';