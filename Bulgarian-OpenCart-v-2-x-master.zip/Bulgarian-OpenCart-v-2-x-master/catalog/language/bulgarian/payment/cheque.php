<?php
/*
 * OpenCart Bulgarian translation
 * Author: Veselin Totev (veselin.totev@gmail.com)
 * License: Free to use
 * Donate:
 *      PayPal: veskoto@gmail.com
 *      Bitcoin: 1QG2f8mGtbYiHc6k8ZzV4WhfcmVHs79QiK
 */
// Text
$_['text_title']				= 'Чек / Пощенски запис';
$_['text_instruction']			= 'Чек / Пощенски запис инструкции';
$_['text_payable']				= 'Платими на: ';
$_['text_address']				= 'Изпрати на: ';
$_['text_payment']				= 'Поръчката Ви нама да бъде изпратена, докато не получим плащане.';