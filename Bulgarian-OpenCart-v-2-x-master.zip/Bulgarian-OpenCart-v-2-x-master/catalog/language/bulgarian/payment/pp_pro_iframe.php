<?php
/*
 * OpenCart Bulgarian translation
 * Author: Veselin Totev (veselin.totev@gmail.com)
 * License: Free to use
 * Donate:
 *      PayPal: veskoto@gmail.com
 *      Bitcoin: 1QG2f8mGtbYiHc6k8ZzV4WhfcmVHs79QiK
 */
// Text
$_['text_title']				= 'Кредитна / Дебитна карта';
$_['text_secure_connection']	= 'Създава се защитена връзка...';

// Error
$_['error_connection']			= 'Възника проблем при осъществяването на връзка с PayPal. Моля, свържете се с администратора на магазина или изберете друг начин на плащане.';