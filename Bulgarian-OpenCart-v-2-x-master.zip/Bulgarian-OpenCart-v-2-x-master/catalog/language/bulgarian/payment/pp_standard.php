<?php
/*
 * OpenCart Bulgarian translation
 * Author: Veselin Totev (veselin.totev@gmail.com)
 * License: Free to use
 * Donate:
 *      PayPal: veskoto@gmail.com
 *      Bitcoin: 1QG2f8mGtbYiHc6k8ZzV4WhfcmVHs79QiK
 */
// Text
$_['text_title']	= 'PayPal';
$_['text_testmode']	= 'Внимание: Връзката за плащане е в \'Sandbox Mode\'. Вашият профил няма да бъде задължен / таксуван.';
$_['text_total']	= 'Доставка, Обработка, Намаления и Данъци';