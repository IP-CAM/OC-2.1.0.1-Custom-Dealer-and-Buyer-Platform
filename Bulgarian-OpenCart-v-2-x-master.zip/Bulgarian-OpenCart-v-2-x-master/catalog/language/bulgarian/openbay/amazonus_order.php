<?php
/*
 * OpenCart Bulgarian translation
 * Author: Veselin Totev (veselin.totev@gmail.com)
 * License: Free to use
 * Donate:
 *      PayPal: veskoto@gmail.com
 *      Bitcoin: 1QG2f8mGtbYiHc6k8ZzV4WhfcmVHs79QiK
 */
// Text
$_['text_paid_amazon'] 			= 'Платено на Amazon US';
$_['text_total_shipping'] 		= 'Доставка';
$_['text_total_shipping_tax'] 	= 'Доставна такса';
$_['text_total_giftwrap'] 		= 'Подаръчна опаковка';
$_['text_total_giftwrap_tax'] 	= 'Подаръчна опаковка такса';
$_['text_total_sub'] 			= 'Междинна сума';
$_['text_tax'] 					= 'Такса';
$_['text_total'] 				= 'Общо';