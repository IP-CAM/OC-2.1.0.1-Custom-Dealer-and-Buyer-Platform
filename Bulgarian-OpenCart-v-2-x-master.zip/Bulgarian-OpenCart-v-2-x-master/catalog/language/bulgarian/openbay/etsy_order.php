<?php
/*
 * OpenCart Bulgarian translation
 * Author: Veselin Totev (veselin.totev@gmail.com)
 * License: Free to use
 * Donate:
 *      PayPal: veskoto@gmail.com
 *      Bitcoin: 1QG2f8mGtbYiHc6k8ZzV4WhfcmVHs79QiK
 */
// Text
$_['text_total_shipping']		= 'Доставка';
$_['text_total_discount']		= 'Отстъпка';
$_['text_total_tax']			= 'Данък';
$_['text_total_sub']			= 'Междинна сума';
$_['text_total']				= 'Общо';