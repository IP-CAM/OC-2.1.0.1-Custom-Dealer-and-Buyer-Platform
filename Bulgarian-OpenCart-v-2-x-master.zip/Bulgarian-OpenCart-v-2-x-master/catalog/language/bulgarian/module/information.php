<?php
/*
 * OpenCart Bulgarian translation
 * Author: Veselin Totev (veselin.totev@gmail.com)
 * License: Free to use
 * Donate:
 *      PayPal: veskoto@gmail.com
 *      Bitcoin: 1QG2f8mGtbYiHc6k8ZzV4WhfcmVHs79QiK
 */
// Heading
$_['heading_title'] = 'Информация';

// Text
$_['text_contact']  = 'Връзка с нас';
$_['text_sitemap']  = 'Карта на сайта';