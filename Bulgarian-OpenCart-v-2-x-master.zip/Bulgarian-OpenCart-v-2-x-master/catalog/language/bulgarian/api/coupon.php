<?php
/*
 * OpenCart Bulgarian translation
 * Author: Veselin Totev (veselin.totev@gmail.com)
 * License: Free to use
 * Donate:
 *      PayPal: veskoto@gmail.com
 *      Bitcoin: 1QG2f8mGtbYiHc6k8ZzV4WhfcmVHs79QiK
 */
// Text
$_['text_success']     = 'Успешно приложихте вашият купон за отстъпка!';

// Error
$_['error_permission'] = 'Внимание нямате достъп!';
$_['error_coupon']     = 'Внимание: Купон е невалиден, изтекъл или е достигнат лимитът му!';