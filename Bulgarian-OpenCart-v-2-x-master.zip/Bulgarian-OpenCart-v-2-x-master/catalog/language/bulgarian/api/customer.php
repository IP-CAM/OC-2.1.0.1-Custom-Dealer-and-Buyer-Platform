<?php
/*
 * OpenCart Bulgarian translation
 * Author: Veselin Totev (veselin.totev@gmail.com)
 * License: Free to use
 * Donate:
 *      PayPal: veskoto@gmail.com
 *      Bitcoin: 1QG2f8mGtbYiHc6k8ZzV4WhfcmVHs79QiK
 */
// Text
$_['text_success']       = 'Успешно променихте потребителя';

// Error
$_['error_permission']   = 'Внимание нямате разрешение за достъп.';
$_['error_firstname']    = 'Името трябва да бъде между 1 и 32 символа!';
$_['error_lastname']     = 'Фамилията трябва да бъде между 1 и 32 символа!';
$_['error_email']        = 'Имейл адресът не е валиден!';
$_['error_telephone']    = 'Телефонът трябва да бъде между 3 и 32 символа!';
$_['error_custom_field'] = '%s задължетелен!';