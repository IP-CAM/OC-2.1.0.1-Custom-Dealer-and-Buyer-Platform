<?php
/*
 * OpenCart Bulgarian translation
 * Author: Veselin Totev (veselin.totev@gmail.com)
 * License: Free to use
 * Donate:
 *      PayPal: veskoto@gmail.com
 *      Bitcoin: 1QG2f8mGtbYiHc6k8ZzV4WhfcmVHs79QiK
 */
// Heading
$_['heading_title']    = 'Профилактика';

// Text
$_['text_maintenance'] = 'Профилактика';
$_['text_message']     = '<h1 style="text-align:center;">В момента извършваме планирана профилактика. <br/>Стараем се да я завършим възможно най-бързо. Моля, посетете ни отново малко по-късно.</h1>';