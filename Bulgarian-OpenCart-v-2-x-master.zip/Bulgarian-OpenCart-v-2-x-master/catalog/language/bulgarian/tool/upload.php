<?php
/*
 * OpenCart Bulgarian translation
 * Author: Veselin Totev (veselin.totev@gmail.com)
 * License: Free to use
 * Donate:
 *      PayPal: veskoto@gmail.com
 *      Bitcoin: 1QG2f8mGtbYiHc6k8ZzV4WhfcmVHs79QiK
 */
// Text
$_['text_upload']    = 'Вашият файл е качен успешно!';

// Error
$_['error_filename'] = 'Името на файлта трябва да бъде между 3 и 64 символа!';
$_['error_filetype'] = 'Невалиден тип файл!';
$_['error_upload']   = 'Качването на файл е задължително!';
