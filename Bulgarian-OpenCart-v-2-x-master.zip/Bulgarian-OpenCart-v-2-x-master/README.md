# Bulgarian translation for OpenCart v.2.x
### Author: Veselin Totev (veselin.totev@gmail.com)
### License: Free to use, Free to edit, Free to commit changes. Free
### Donate:
####PayPal: veselin.totev@gmail.com
####Bitcoin: 1QG2f8mGtbYiHc6k8ZzV4WhfcmVHs79QiK
