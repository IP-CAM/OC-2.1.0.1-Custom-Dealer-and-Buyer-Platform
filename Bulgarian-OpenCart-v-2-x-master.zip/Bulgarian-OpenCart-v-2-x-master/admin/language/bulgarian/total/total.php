<?php
// Heading
$_['heading_title']    = 'Общо';

// Text
$_['text_total']       = 'Order Totals';
$_['text_success']     = 'Успешно: Променихте total totals!';
$_['text_edit']        = 'Редакция Total Total';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Подредба';

// Error
$_['error_permission'] = 'Внимание: Нямате права за редакция на total totals!';