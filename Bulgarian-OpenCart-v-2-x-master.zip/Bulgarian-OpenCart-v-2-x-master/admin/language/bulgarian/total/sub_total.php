<?php
// Heading
$_['heading_title']    = 'Sub-Total';

// Text
$_['text_total']       = 'Order Totals';
$_['text_success']     = 'Успешно: Променихте sub-total total!';
$_['text_edit']        = 'Редакция Sub-Total Total';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Подредба';

// Error
$_['error_permission'] = 'Внимание: Нямате права за редакция на sub-total total!';