<?php
// Heading
$_['heading_title']    = 'Gift Voucher';

// Text
$_['text_total']       = 'Order Totals';
$_['text_success']     = 'Успешно: Променихте gift voucher total!';
$_['text_edit']        = 'Редакция Gift Voucher Total';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Подредба';

// Error
$_['error_permission'] = 'Внимание: Нямате права за редакция на gift voucher total!';