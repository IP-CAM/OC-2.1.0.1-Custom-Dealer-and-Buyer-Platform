<?php
/*
 * OpenCart Bulgarian translation
 * Author: Veselin Totev (veselin.totev@gmail.com)
 * License: Free to use
 * Donate:
 *      PayPal: veskoto@gmail.com
 *      Bitcoin: 1QG2f8mGtbYiHc6k8ZzV4WhfcmVHs79QiK
 */
// Heading
$_['heading_title']     = 'Последни поръчки';

// Column
$_['column_order_id']   = 'Поръчка ID';
$_['column_customer']   = 'Клиент';
$_['column_status']     = 'Статус';
$_['column_total']      = 'Всичко';
$_['column_date_added'] = 'Дата';
$_['column_action']     = 'Действие';