<?php
// Heading
$_['heading_title']	   = 'Error Log';

// Text
$_['text_success']	   = 'Успешно: You have successfully cleared your error log!';
$_['text_list']        = 'Errors Списък';

// Error
$_['error_warning']	   = 'Внимание: Your error log file %s is %s!';
$_['error_permission'] = 'Внимание: You do not have permission to clear error log!';