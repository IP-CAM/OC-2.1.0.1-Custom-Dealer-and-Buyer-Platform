<?php
// Heading
$_['heading_title']    = 'Pickup From Store';

// Text
$_['text_shipping']    = 'Shipping';
$_['text_success']     = 'Успешно: Променихте pickup from store!';
$_['text_edit']        = 'Редакция Pickup From Store Shipping';

// Entry
$_['entry_geo_zone']   = 'Географска зона';
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Подредба';

// Error
$_['error_permission'] = 'Внимание: Нямате права за редакция на pickup from store!';