<?php
/*
 * OpenCart Bulgarian translation
 * Author: Veselin Totev (veselin.totev@gmail.com)
 * License: Free to use
 * Donate:
 *      PayPal: veskoto@gmail.com
 *      Bitcoin: 1QG2f8mGtbYiHc6k8ZzV4WhfcmVHs79QiK
 */
// Text
$_['text_subject']       = '%s - Актуализация за връщане %s';
$_['text_return_id']     = 'Връщане ID:';
$_['text_date_added']    = 'Дата на връщане:';
$_['text_return_status'] = 'Връщането Ви е актуализирано на следния статус:';
$_['text_comment']       = 'Коментара е:';
$_['text_footer']        = 'Моля, отговорете на този имейл, ако имате някакви въпроси.';