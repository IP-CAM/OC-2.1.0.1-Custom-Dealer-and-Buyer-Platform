<?php
/*
 * OpenCart Bulgarian translation
 * Author: Veselin Totev (veselin.totev@gmail.com)
 * License: Free to use
 * Donate:
 *      PayPal: veskoto@gmail.com
 *      Bitcoin: 1QG2f8mGtbYiHc6k8ZzV4WhfcmVHs79QiK
 */
// Text
$_['text_subject']  = '%s - искане за нулиране парола';
$_['text_greeting'] = 'Нова парола беше поискана %s администрация.';
$_['text_change']   = 'За да възстановите паролата си, кликнете на линка по-долу:';
$_['text_ip']       = 'IP адреса използван за тази заявка е: %s';